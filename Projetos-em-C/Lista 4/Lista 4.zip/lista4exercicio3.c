// Autor: Willian Cozzi Candido
/*Fa�a um programa em C para ler uma matriz 5 x 10 que se refere a respostas de 10 quest�es de m�ltipla escolha, referentes a 5 alunos. 
Leia tamb�m um vetor de 10 posi��es contendo o gabarito de respostas que podem ser a, b, c ou d. Seu programa dever� comparar as 
respostas de cada aluno com o gabarito e armazenar em um outro vetor denominado resultado, contendo a pontua��o correspondente a cada aluno.*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	int mat[5][10];
	




}


